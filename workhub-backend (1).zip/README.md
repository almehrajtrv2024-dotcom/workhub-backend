# WorkHub Backend

This is a simple Node.js + Express backend for WorkHub.

## Setup

```bash
npm install
npm start
```

Server will run on `http://localhost:5000`
