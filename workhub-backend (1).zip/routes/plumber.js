const express = require("express");
const router = express.Router();

// sample plumber data
const plumbers = [
  { id: 1, name: "Rahul Kumar", experience: "5 years" },
  { id: 2, name: "Arjun Singh", experience: "3 years" }
];

router.get("/", (req, res) => {
  res.json(plumbers);
});

module.exports = router;
