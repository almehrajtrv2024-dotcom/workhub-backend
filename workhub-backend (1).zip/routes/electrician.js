const express = require("express");
const router = express.Router();

// sample electrician data
const electricians = [
  { id: 1, name: "Amit Verma", experience: "4 years" },
  { id: 2, name: "Suresh Yadav", experience: "6 years" }
];

router.get("/", (req, res) => {
  res.json(electricians);
});

module.exports = router;
